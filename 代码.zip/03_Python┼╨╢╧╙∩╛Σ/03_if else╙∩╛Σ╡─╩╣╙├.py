"""
演示Python中
if else的组合判断语句
"""
age = int(input("请输入你的年龄："))

if age >= 18:
    print("您已成年，需要买票10元。")
else:
    print("您未成年，可以免费游玩。")



